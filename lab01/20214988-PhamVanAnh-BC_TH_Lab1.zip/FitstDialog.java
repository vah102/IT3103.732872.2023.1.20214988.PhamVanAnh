//Ex2: FirstDialog.java
//Author: Pham Van Anh 20214988
//import Package javax.swing to use the dialog

import javax.swing.JOptionPane;

public class FitstDialog {

    public static void main(String[] args) {
        //use the method showDialog to print text to cmd
        JOptionPane.showMessageDialog(null, "Hello world! How are you?");

        //exits current program by terminating running Java virtual machine
        System.exit(0);
    }
}

